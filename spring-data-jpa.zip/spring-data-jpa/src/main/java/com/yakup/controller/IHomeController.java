package com.yakup.controller;

import com.yakup.dto.DtoHome;

public interface IHomeController {

	public DtoHome findHomeById(long id);
}
