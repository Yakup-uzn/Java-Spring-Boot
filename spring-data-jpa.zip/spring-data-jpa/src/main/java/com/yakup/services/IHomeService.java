package com.yakup.services;

import com.yakup.dto.DtoHome;

public interface IHomeService {
	public DtoHome findHomeById(long id);
}
